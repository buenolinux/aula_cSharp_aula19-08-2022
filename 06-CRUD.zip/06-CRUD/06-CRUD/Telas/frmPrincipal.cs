﻿using _06_CRUD.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _06_CRUD.Telas
{
    public partial class frmPrincipal : Form
    {
        Usuario usuarioLogado = new Usuario();
        public frmPrincipal(Usuario uso)
        {
            InitializeComponent();
            usuarioLogado = uso;
        }

        private void dtpNascimento_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
